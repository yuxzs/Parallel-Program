#ifndef RANDDP_H
#define RANDDP_H

double randlc(double *x, double a);
void vranlc(int n, double *x, double a, double y[]);

#endif // RANDDP_H
