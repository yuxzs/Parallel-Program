#ifndef TEST_H
#define TEST_H

// Run for multiple experiments to reduce measurement error on gettime().
#define I 20000000

#endif
