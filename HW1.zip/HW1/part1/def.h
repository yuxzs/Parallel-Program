// Define vector unit width here
#ifndef VECTOR_WIDTH
#define VECTOR_WIDTH 4
#endif
#define EXP_MAX 10
